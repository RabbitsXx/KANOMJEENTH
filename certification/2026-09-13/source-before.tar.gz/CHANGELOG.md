# Changelog

## 0.1.0-staging

Initial Kanomjeen integrated staging suite.

### Added
- Shared `Kanomjeen.Core` runtime services.
- Combat and raid tagging.
- Config/static + dynamic restricted zones.
- Persistent feature cooldowns.
- Cross-feature teleport lock.
- Exact/ambiguous-safe online player resolver.
- Command/UI rate limiting.
- Workshop UI server bridge and contract v1.0.
- TPA with request caps, warmup, movement/damage/death cancellation and persistent successful-teleport cooldown.
- Persistent homes with configurable limits, warmup and PvP/raid/zone restrictions.
- Permission-controlled utility kits with persistent cooldown.
- Respawn protection.
- BuildGuard placement limits and zone/item blocking.
- Scheduled/forced airdrops with dynamic objective restrictions.
- Persistent player statistics.
- Safe-save restart manager and announcements.
- Moderation commands, persistent mutes/warnings and buffered JSONL audit.
- Vehicle inspection and event logging without a virtual garage.
- Unity Editor Workshop UI prefab builder.
- Build/install/source-verification scripts for Windows and Linux.
- Release manifest, permissions guide, installation guide and QA matrix.

### Security / exploit hardening
- TPA/Home cannot run simultaneous teleport warmups for the same player.
- Teleport requests are revalidated immediately before teleport.
- GUI callbacks repeat server-side authority checks.
- Core disconnect cleanup releases teleport/rate/runtime state.
- Kit cooldown is committed before item delivery to prevent repeated partial-delivery duplication.

### Release note
This version is staging source. It requires local compile certification, Unity masterbundle export, dedicated-server runtime testing and California 2 coordinate configuration before production.
